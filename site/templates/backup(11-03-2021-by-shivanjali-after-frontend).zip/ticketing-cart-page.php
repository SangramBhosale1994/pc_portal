<?php
/*
	File created 2021-03-07
	Primary code by Amrut Todkar

	This page will show all the tickets added to the cart and the total to the user.
	Page will contain:
	-After adding all the tickets, the user will go to the cart page. The cart page will show a list of all the tickets that the user has added with the information filled for each ticket.
	-The user can remove a ticket from their cart at this point.
	-There will be a button to go back to the Tickets page if they want to go back and add more tickets.
	-Once satisfied with the ticket information, the user can click on “Checkout” page
*/

require_once 'includes/ticketing-header.php';


/* Check if the ticket deletion form was submitted from front-end. -by checking if there is a post value of the delete button name */
if (isset($_POST["delete_ticket_button"])) {

	/* Get which ticket is to be deleted from the cart. use sanitizer as the value needs to be an integer. */
	$ticket_index_to_delete = $input->post->int('delete_ticket_button');

	/* Convert the JSON of tickets in the cart (session) into an object. */
	$cart_tickets_object = json_decode($session->tickets_json);

	/* Remove that one particular ticket from the array. array_splice (https://www.w3schools.com/php/func_array_splice.asp) */
	//array_splice($cart_tickets_object->tickets_array, $ticket_index_to_delete, 1);
	unset($cart_tickets_object->$ticket_index_to_delete);

	/* Save the new array to the cart again by encoding the object into JSON */
	$session->tickets_json = json_encode($cart_tickets_object);
}
/* Check if the ticket deletion form was submitted END */

/* Show the list of all the tickets that are saved in the session (CART) */

/* TODO
		1. Check if the object ($cart_tickets_object) has no values. If There are no tickets in the object, it should show, "There are no tickets in your cart!" In the else part, put the following loop.
	*/

/* Convert the JSON of tickets in the cart (session) into an object. */
$cart_tickets_object = json_decode($session->tickets_json);
$total = 0;
/* Loop to go through each ticket added in the cart and show the details */
// foreach ($cart_tickets_object as $cart_ticket_key => $single_ticket_object) {
// 	$total += $single_ticket_object->price
?>
	<!--Ticket Index in the cart: <?= $cart_ticket_key ?>-->
	<!--<br>-->
	<!--attendee_name: <?= $single_ticket_object->attendee_name ?>-->
	<!--<br>-->
	<!--attendee_country_code: <?= $single_ticket_object->attendee_country_code ?>-->
	<!--<br>-->
	<!--attendee_phone_number: <?= $single_ticket_object->attendee_phone_number ?>-->
	<!--<br>-->
	<!--event_id: <?= $single_ticket_object->event_id ?>-->
	<!--<br>-->
	<!--event_price: <?= $single_ticket_object->price ?>-->
	<!--<br>-->
	<?php
	/* This form will be repeated for each ticket. Each form will have a quniue ID.
		Each form has only one button. The button is for deletion and each button has a separate value but the same name.
		This is to identify on the back-end that the delete button was pressed. But the value of the button will decide which ticket is to be deleted from the cart. */
	?>
	<!--<form method="POST" id="ticket_deletion_form_<?= $cart_ticket_key ?>">-->
	<!--	<button name="delete_ticket_button" value="<?= $cart_ticket_key ?>">DELETE</button>-->
	<!--</form>-->
	<!--<hr>-->

<?php
// }
/* Loop to go through each ticket added in the cart and show the details END */
?>
<div class="container">
    <h2 class="text-center">Cart</h2>
</div>
<div class="container">
   
    
    
    <div class="shopping-cart">
 
        <h2 class="text-center">Cart</h2>
     <?php
                $total=0;
               	foreach (json_decode($session->tickets_json) as $cart_ticket_key => $single_ticket) 
               	{
                    $total+=$single_ticket->price;
                    
               
            ?>
    
        <div class="card w-100" style="margin-bottom:2rem;">
          <div class="card-body">
            <h5 class="card-title"><?=$pages->get("name=events")->child("ticketing_event_id=".$single_ticket->event_id)->title ?></h5>
            <div class="card-text">
                 <div class="product">
    <!--<div class="product-image">-->
    <!--  <img src="images/nike.jpg">-->
    <!--</div>-->
    <div class="product-details">
      <div class="product-title"><?=$pages->get("name=events")->child("ticketing_event_id=".$single_ticket->event_id)->title ?></div>
      <p class="product-description"><?=$pages->get("name=events")->child("ticketing_event_id=".$single_ticket->event_id)->ticketing_event_description?></p>
    </div>
    <div class="product-price"><?=$single_ticket->price?></div>
    <div class="product-quantity">
      <!--<input type="number" value="2" min="1">-->
      <?=$single_ticket->attendee_phone_number?>
    </div>
    <div class="product-removal">
      <!--<button class="remove-product"  name="delete_ticket_button" value="<?= $cart_ticket_key ?>">DELETE</button>-->
        <form method="POST" id="ticket_deletion_form_<?= $cart_ticket_key ?>">
  <button name="delete_ticket_button" class="remove-product" value="<?= $cart_ticket_key ?>">DELETE</button>
 </form>
      
    </div>
    
  </div>
 
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Attendee Information</h3>
                    <p> Name : <?=$single_ticket->attendee_name." ". $single_ticket->attendee_preferred_name?></p>
                     <p>Pronoun : <?=$single_ticket->attendee_pronoun?></p>
                     <p>Phone number : <?=$single_ticket->attendee_phone_country_code?>-<?=$single_ticket->attendee_phone_number?></p>
                     <p>Email : <?=$single_ticket->attendee_email?></p>
                     <p>Company Name : <?=$single_ticket-> attendee_company_name?></p>
                      
                     
                </div>
                
            </div>
        </div>
    </div>

        </div>
</div>
 
 
    </div>
 
 <?php
               	}
               	if ($total != 0) {

	
	        ?>
	            <div class="">
	                <div class="d-flex justify-content-between container" style="border:2px solid rgba(1, 1, 1, 0.1); margin-top:2rem;">
	                <div style="margin-top:2rem; margin-bottom:2rem;">
	                    <h5 class="">Total </h5>
	                </div>
	                <div style="margin-top:2rem; margin-bottom:2rem;">
	                     <p class="card-text" style="">
                            <?php
                                    	echo  $total;
                            ?>
        
                        </p>
	                </div>
	                
	            </div>
	            </div>
	            
	        

	        <?php
	
	
            } else {
            	echo "There are no tickets in your cart!";
            }
?><br>
<!--<a href="<?= $page->parent->url ?>">Add More</a>-->
<!--<br/>-->
<!--<a href="<?= $page->parent->url ?>thank-you">Checkout</a>-->
   <div class="d-flex justify-content-center" style="padding-bottom:3rem;">          	
<a href="<?= $page->parent->url ?>" class="text-center" style=""><button type="button" class="btn btn-primary">Add More</button></a>	

      
<!--<a href="<?= $pages->get("name=checkout")->httpUrl ?>"  class="text-center"><button type="button" class="btn btn-primary">Checkout</button></a>-->
</div>  

     <!--<div class="text-center">-->
     <!--     <button class="checkout text-center">Checkout</button>-->
     <!--</div>  -->
     
 
  <!--checkout form-->
    <div class="container" style="margin-bottom:3rem;">
        <div class="row">
            <div class="col-md-2"></div>
              <div class="col-md-8">
                    <form class="needs-validation" novalidate>

    <div class="form-group">
      <label for="billing_name">Bill in the Name of </label>
      <input type="text" class="form-control" id="billing_name" pattern="^[A-Za-z'\s\.\-]{1,}[\.]{0,}[A-Za-z'\s\.\-]{0,}$" placeholder="Name" required>
           <div class="invalid-feedback">
                 Please enter valid Name 
         </div>
    </div>
    <div class="form-group">
      <label for="billing_compnay_name">Company Name</label>
      <input type="text" class="form-control" id="billing_compnay_name" placeholder="Company Name" pattern="^[A-Za-z'\s\.\-]{1,}[\.]{0,}[A-Za-z'\s\.\-]{0,}$" required>
           <div class="invalid-feedback">
                 Please enter valid Company Name 
         </div>
    </div>
   	<div class="[  ][ form-group ]">
				<label for="billing_email">Email</label>
				<input id="billing_email" class="form-control" type="email" pattern='^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$' name="billing_email" placeholder="abc@xyz.com" value="<?=$session->oauth_gmail;?>" required>

				<div class="invalid-tooltip">
					Please provide a valid email address.
				</div>
			</div>
 
    	<div class="[ ][ form-group ]">
				<label for="phone_number">Phone number</label>

			        	<div class="row no-gutters">
        					<select id="phone_country_code" class="[ col-4 pl-2 ][ custom-select ]" name="phone_country_code">
        						<option value="+376">(AD) +376</option>
        						<option value="+971">(AE) +971</option>
        						<option value="+93">(AF) +93</option>
        						<option value="+1-268">(AG) +1-268</option>
        						<option value="+1-264">(AI) +1-264</option>
        						<option value="+355">(AL) +355</option>
        						<option value="+374">(AM) +374</option>
        						<option value="+599">(AN) +599</option>
        						<option value="+244">(AO) +244</option>
        						<option value="+672">(AQ) +672</option>
        						<option value="+54">(AR) +54</option>
        						<option value="+1-684">(AS) +1-684</option>
        						<option value="+43">(AT) +43</option>
        						<option value="+61">(AU) +61</option>
        						<option value="+297">(AW) +297</option>
        						<option value="+994">(AZ) +994</option>
        						<option value="+387">(BA) +387</option>
        						<option value="+1-246">(BB) +1-246</option>
        						<option value="+880">(BD) +880</option>
        						<option value="+32">(BE) +32</option>
        						<option value="+226">(BF) +226</option>
        						<option value="+359">(BG) +359</option>
        						<option value="+973">(BH) +973</option>
        						<option value="+257">(BI) +257</option>
        						<option value="+229">(BJ) +229</option>
        						<option value="+590">(BL) +590</option>
        						<option value="+1-441">(BM) +1-441</option>
        						<option value="+673">(BN) +673</option>
        						<option value="+591">(BO) +591</option>
        						<option value="+55">(BR) +55</option>
        						<option value="+1-242">(BS) +1-242</option>
        						<option value="+975">(BT) +975</option>
        						<option value="+267">(BW) +267</option>
        						<option value="+375">(BY) +375</option>
        						<option value="+501">(BZ) +501</option>
        						<option value="+1">(CA) +1</option>
        						<option value="+61">(CC) +61</option>
        						<option value="+243">(CD) +243</option>
        						<option value="+236">(CF) +236</option>
        						<option value="+242">(CG) +242</option>
        						<option value="+41">(CH) +41</option>
        						<option value="+225">(CI) +225</option>
        						<option value="+682">(CK) +682</option>
        						<option value="+56">(CL) +56</option>
        						<option value="+237">(CM) +237</option>
        						<option value="+86">(CN) +86</option>
        						<option value="+57">(CO) +57</option>
        						<option value="+506">(CR) +506</option>
        						<option value="+53">(CU) +53</option>
        						<option value="+238">(CV) +238</option>
        						<option value="+599">(CW) +599</option>
        						<option value="+61">(CX) +61</option>
        						<option value="+357">(CY) +357</option>
        						<option value="+420">(CZ) +420</option>
        						<option value="+49">(DE) +49</option>
        						<option value="+253">(DJ) +253</option>
        						<option value="+45">(DK) +45</option>
        						<option value="+1-767">(DM) +1-767</option>
        						<option value="+1-809">(DO) +1-809</option>
        						<option value="+213">(DZ) +213</option>
        						<option value="+593">(EC) +593</option>
        						<option value="+372">(EE) +372</option>
        						<option value="+20">(EG) +20</option>
        						<option value="+212">(EH) +212</option>
        						<option value="+291">(ER) +291</option>
        						<option value="+34">(ES) +34</option>
        						<option value="+251">(ET) +251</option>
        						<option value="+358">(FI) +358</option>
        						<option value="+679">(FJ) +679</option>
        						<option value="+500">(FK) +500</option>
        						<option value="+691">(FM) +691</option>
        						<option value="+298">(FO) +298</option>
        						<option value="+33">(FR) +33</option>
        						<option value="+241">(GA) +241</option>
        						<option value="+44">(GB) +44</option>
        						<option value="+1-473">(GD) +1-473</option>
        						<option value="+995">(GE) +995</option>
        						<option value="+44-1481">(GG) +44-1481</option>
        						<option value="+233">(GH) +233</option>
        						<option value="+350">(GI) +350</option>
        						<option value="+299">(GL) +299</option>
        						<option value="+220">(GM) +220</option>
        						<option value="+224">(GN) +224</option>
        						<option value="+240">(GQ) +240</option>
        						<option value="+30">(GR) +30</option>
        						<option value="+502">(GT) +502</option>
        						<option value="+1-671">(GU) +1-671</option>
        						<option value="+245">(GW) +245</option>
        						<option value="+592">(GY) +592</option>
        						<option value="+852">(HK) +852</option>
        						<option value="+504">(HN) +504</option>
        						<option value="+385">(HR) +385</option>
        						<option value="+509">(HT) +509</option>
        						<option value="+36">(HU) +36</option>
        						<option value="+62">(ID) +62</option>
        						<option value="+353">(IE) +353</option>
        						<option value="+972">(IL) +972</option>
        						<option value="+44-1624">(IM) +44-1624</option>
        						<option value="+91" selected>(IN) +91</option>
        						<option value="+246">(IO) +246</option>
        						<option value="+964">(IQ) +964</option>
        						<option value="+98">(IR) +98</option>
        						<option value="+354">(IS) +354</option>
        						<option value="+39">(IT) +39</option>
        						<option value="+44-1534">(JE) +44-1534</option>
        						<option value="+1-876">(JM) +1-876</option>
        						<option value="+962">(JO) +962</option>
        						<option value="+81">(JP) +81</option>
        						<option value="+254">(KE) +254</option>
        						<option value="+996">(KG) +996</option>
        						<option value="+855">(KH) +855</option>
        						<option value="+686">(KI) +686</option>
        						<option value="+269">(KM) +269</option>
        						<option value="+1-869">(KN) +1-869</option>
        						<option value="+850">(KP) +850</option>
        						<option value="+82">(KR) +82</option>
        						<option value="+965">(KW) +965</option>
        						<option value="+1-345">(KY) +1-345</option>
        						<option value="+7">(KZ) +7</option>
        						<option value="+856">(LA) +856</option>
        						<option value="+961">(LB) +961</option>
        						<option value="+1-758">(LC) +1-758</option>
        						<option value="+423">(LI) +423</option>
        						<option value="+94">(LK) +94</option>
        						<option value="+231">(LR) +231</option>
        						<option value="+266">(LS) +266</option>
        						<option value="+370">(LT) +370</option>
        						<option value="+352">(LU) +352</option>
        						<option value="+371">(LV) +371</option>
        						<option value="+218">(LY) +218</option>
        						<option value="+212">(MA) +212</option>
        						<option value="+377">(MC) +377</option>
        						<option value="+373">(MD) +373</option>
        						<option value="+382">(ME) +382</option>
        						<option value="+590">(MF) +590</option>
        						<option value="+261">(MG) +261</option>
        						<option value="+692">(MH) +692</option>
        						<option value="+389">(MK) +389</option>
        						<option value="+223">(ML) +223</option>
        						<option value="+95">(MM) +95</option>
        						<option value="+976">(MN) +976</option>
        						<option value="+853">(MO) +853</option>
        						<option value="+1-670">(MP) +1-670</option>
        						<option value="+222">(MR) +222</option>
        						<option value="+1-664">(MS) +1-664</option>
        						<option value="+356">(MT) +356</option>
        						<option value="+230">(MU) +230</option>
        						<option value="+960">(MV) +960</option>
        						<option value="+265">(MW) +265</option>
        						<option value="+52">(MX) +52</option>
        						<option value="+60">(MY) +60</option>
        						<option value="+258">(MZ) +258</option>
        						<option value="+264">(NA) +264</option>
        						<option value="+687">(NC) +687</option>
        						<option value="+227">(NE) +227</option>
        						<option value="+234">(NG) +234</option>
        						<option value="+505">(NI) +505</option>
        						<option value="+31">(NL) +31</option>
        						<option value="+47">(NO) +47</option>
        						<option value="+977">(NP) +977</option>
        						<option value="+674">(NR) +674</option>
        						<option value="+683">(NU) +683</option>
        						<option value="+64">(NZ) +64</option>
        						<option value="+968">(OM) +968</option>
        						<option value="+507">(PA) +507</option>
        						<option value="+51">(PE) +51</option>
        						<option value="+689">(PF) +689</option>
        						<option value="+675">(PG) +675</option>
        						<option value="+63">(PH) +63</option>
        						<option value="+92">(PK) +92</option>
        						<option value="+48">(PL) +48</option>
        						<option value="+508">(PM) +508</option>
        						<option value="+64">(PN) +64</option>
        						<option value="+1-787">(PR) +1-787</option>
        						<option value="+970">(PS) +970</option>
        						<option value="+351">(PT) +351</option>
        						<option value="+680">(PW) +680</option>
        						<option value="+595">(PY) +595</option>
        						<option value="+974">(QA) +974</option>
        						<option value="+262">(RE) +262</option>
        						<option value="+40">(RO) +40</option>
        						<option value="+381">(RS) +381</option>
        						<option value="+7">(RU) +7</option>
        						<option value="+250">(RW) +250</option>
        						<option value="+966">(SA) +966</option>
        						<option value="+677">(SB) +677</option>
        						<option value="+248">(SC) +248</option>
        						<option value="+249">(SD) +249</option>
        						<option value="+46">(SE) +46</option>
        						<option value="+65">(SG) +65</option>
        						<option value="+290">(SH) +290</option>
        						<option value="+386">(SI) +386</option>
        						<option value="+47">(SJ) +47</option>
        						<option value="+421">(SK) +421</option>
        						<option value="+232">(SL) +232</option>
        						<option value="+378">(SM) +378</option>
        						<option value="+221">(SN) +221</option>
        						<option value="+252">(SO) +252</option>
        						<option value="+597">(SR) +597</option>
        						<option value="+211">(SS) +211</option>
        						<option value="+239">(ST) +239</option>
        						<option value="+503">(SV) +503</option>
        						<option value="+1-721">(SX) +1-721</option>
        						<option value="+963">(SY) +963</option>
        						<option value="+268">(SZ) +268</option>
        						<option value="+1-649">(TC) +1-649</option>
        						<option value="+235">(TD) +235</option>
        						<option value="+228">(TG) +228</option>
        						<option value="+66">(TH) +66</option>
        						<option value="+992">(TJ) +992</option>
        						<option value="+690">(TK) +690</option>
        						<option value="+670">(TL) +670</option>
        						<option value="+993">(TM) +993</option>
        						<option value="+216">(TN) +216</option>
        						<option value="+676">(TO) +676</option>
        						<option value="+90">(TR) +90</option>
        						<option value="+1-868">(TT) +1-868</option>
        						<option value="+688">(TV) +688</option>
        						<option value="+886">(TW) +886</option>
        						<option value="+255">(TZ) +255</option>
        						<option value="+380">(UA) +380</option>
        						<option value="+256">(UG) +256</option>
        						<option value="+1">(US) +1</option>
        						<option value="+598">(UY) +598</option>
        						<option value="+998">(UZ) +998</option>
        						<option value="+379">(VA) +379</option>
        						<option value="+1-784">(VC) +1-784</option>
        						<option value="+58">(VE) +58</option>
        						<option value="+1-284">(VG) +1-284</option>
        						<option value="+1-340">(VI) +1-340</option>
        						<option value="+84">(VN) +84</option>
        						<option value="+678">(VU) +678</option>
        						<option value="+681">(WF) +681</option>
        						<option value="+685">(WS) +685</option>
        						<option value="+383">(XK) +383</option>
        						<option value="+967">(YE) +967</option>
        						<option value="+262">(YT) +262</option>
        						<option value="+27">(ZA) +27</option>
        						<option value="+260">(ZM) +260</option>
        						<option value="+263">(ZW) +263</option>
        					</select>

					<input id="billing_phone_number" class="[ offset-1 col-7 pl-2 ][ form-control ]" pattern="[0-9]{10}" type="text" name="phone_number" placeholder="Example: 9876543210" maxlength="10" required>

					<div class="invalid-tooltip">
						Please provide a valid phone number.
					</div>
				</div>
			</div>
    <div class="form-group">
      <label for="billing_gst_number">GST number </label>
      <input type="text" class="form-control" id="billing_gst_number" placeholder="Name" required>
           <div class="invalid-feedback">
                 Please enter valid GST Number 
         </div>
    </div>
 
  <center><button class="btn btn-primary" type="submit">Confirm and pay</button></center>
</form>
                  
              </div>
                <div class="col-md-2"></div>
         </div>
    </div>
  
  

<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>


<?php
        require_once 'includes/ticketing-footer.php';
?>