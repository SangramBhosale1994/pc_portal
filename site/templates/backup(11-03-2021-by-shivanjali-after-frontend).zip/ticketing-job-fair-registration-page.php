<?php
/*
	File created 2021-03-09
	Primary code by Amrut Todkar

	This page will show a the candidates the form to fill if they want to register for the job fair


*/

	require_once 'includes/ticketing-header.php';


	/* This variable will save the status of the candidate. If they have signed up or not. */
	$is_candidate_signed_up = false;
	$candidate_page = new stdClass;

	/* Check if the candidate's gmail is saved in the session when they logged into the resume portal. IF yes, change the login status. */
	if($session->oauth_gmail != ""){
		$is_candidate_signed_up = true;	

		/* Get the candidate page */
		$candidate_page = $pages->get("name=candidates")->child("oauth_gmail=".$session->oauth_gmail);

	}
	/* Check if the candidate's gmail is saved in the session END */

	/* if the job fair pass application form is submitted, save that to the backend. */
	if(isset($_POST['apply_for_job_fair_submit'])){

		/* Saving all the values sent in the form into a page. */
		/*
			TODO
			- Create a new processwire page here
			- Add all of those values from the from into the page. including the Page ID of the person who is applying.
		*/

		/* Save this into the newly created page as well */
		
		// $np->candidate_page_id = $candidate_page->id;
		// $np->first_name = $input->post->text('attendee_name');
		// $np->country_code = $input->post->text('attendee_country_code');
		// $np->phone_number = $input->post->text('attendee_phone_number');

		/* Saving all the values sent in the form into a page. END */
	}
	/* if the ticket booking form is submitted, save the information in the session END */
?>

<!DOCTYPE html>
<html>
<head>
	<title><?=$page->title?></title>
</head>
<body>


	<?php
		/* Check if the candidate is signed up on the resume portal */
		if($is_candidate_signed_up == true){
			/* If candidate has signed up, show the form to apply to the job fair pass */
			/* The pre-filled values from the candidate's page shall be put here from $candidate_page */
	?>

	<!-- Form to add the ticket to the cart. -->
	<form method="POST">
		attendee_name<input type="text" value="<?=$candidate_page->first_name?>" name="attendee_name">
		attendee_country_code<input type="text" name="attendee_country_code">
		attendee_phone_number<input type="text" name="attendee_phone_number">
		<button type="submit" name="apply_for_job_fair_submit">Submit</button>
	</form>
	<!-- Form to add the ticket to the cart END -->
	
	<?php
			/* If candidate has signed up, show the form to apply to the job fair pass END */
		}
		else{
			/* If the candidate is not signed up, show the Upload Resume button */
			/* This link will take the user to the resume upload section. */
	?>
		<a href="#">Upload Your Resume</a>
	<?php

			/* If the candidate is not signed up, show the Upload Resume button END */

		}
		/* Check if the candidate is signed up on the resume portal END */
	?>

</body>
</html>