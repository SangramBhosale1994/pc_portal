<?php
/*
	File created 2021-03-07
	Primary code by Amrut Todkar

	This page will show a single ticket and the form to add it to the cart to the user.
	Page will contain:
	-The user will see the details of the ticket/event
	-The user will have a form below the details which they have to fill if they want to book the ticket, each ticket the user wants to bu will be filled in with the ticket-holder’s information in this form, the form will have the following fields:
		-First Name*
		-Last Name*
		-Pronouns* 
		-Phone number*
		-Confirm Phone Number*
		-Email ID*
		-Company Name
	-I agree to the T&C checkbox*
	-The user will see the important notices, terms and conditions on this page as well. (Phone number double checking included)
	-The user will not be able to register tickets with conflicting timings for the same phone number.
	-The user can go back and add other tickets after this.
*/

require_once 'includes/ticketing-header.php';

//  if (isset($_POST['submit'])){


//         // echo "Your Ticket is added to cart";
// }


/* if the ticket booking form is submitted, save the information in the session */
if (isset($_POST['add_ticket_submit'])) {
echo "abc";
	/* Saving all the values sent in the form.*/
	/* TODO
			1. Everything should be sanitized using the processwire sanitizer function. (check how $input->post() works with sanitizer as well https://processwire.com/api/ref/wire-input/post/ and this for sanitizerrs- https://processwire.com/api/ref/sanitizer/) OUr processwire version number can be seen in the processwire admin panel.
			2. If a required value is empty, user shall be notified
			3. Backend validation of the input valus should happen here. No invalid values should escape. Testing should be strict.
		*/

	/* Create an object of the input ticket information. and save the info into that. */
	$attendee_ticket_info_object = new stdClass;

	$attendee_ticket_info_object->attendee_name = $input->post->text('legal_name');
	$attendee_ticket_info_object->attendee_preferred_name = $input->post->text('preferred_name');
	$attendee_ticket_info_object->attendee_pronoun = $input->post->text('pronoun');
	$attendee_ticket_info_object->attendee_phone_country_code = $input->post->text('phone_country_code');
    $attendee_ticket_info_object->attendee_phone_number = $input->post->text('phone_number');
	$attendee_ticket_info_object->attendee_email = $input->post->text('email');
	$attendee_ticket_info_object->attendee_company_name = $input->post->text('company_name');
	
	$attendee_ticket_info_object->event_id = $page->ticketing_event_id;
	$attendee_ticket_info_object->price = $page->ticketing_event_price;
	$flag = true;

	foreach (json_decode($session->tickets_json) as $single_ticket) {
		if ($single_ticket->event_id == $attendee_ticket_info_object->event_id && $single_ticket->attendee_phone_number == $attendee_ticket_info_object->attendee_phone_number) {
			$flag = false;
			echo $single_ticket->event_id . " Already added into the cart for" . $attendee_ticket_info_object->attendee_phone_number . " this Mobile number <br>";
		}
	}

	if ($pages->get("name=attendee")->child("ticketing_attendee_phone_number=" . $attendee_ticket_info_object->attendee_phone_number)->children("title=" . $attendee_ticket_info_object->event_id)->count()) {
		// $attendee_page = $pages->get("name=attendee")->child("ticketing_attendee_phone_number=" . $attendee_ticket_info_object->attendee_phone_number);
		// foreach ($attendee_page->children() as $attendee_page_child) {
		// 	if ($attendee_page_child->title == $attendee_ticket_info_object->event_id) {
		$flag = false;
		echo "Can't buy this " . $attendee_ticket_info_object->event_id . " ticket twise<br>";
		//}
		//}
	}

	if ($flag) {
		/* Create an object of the ticket information END */
		/* Saving all the values sent in the form. END */

		/* Adding ticket's name and other additional automatic information into the object */
		/* TODO
			1. Each ticket will have a unique name. That name should be saved to the session as well.
			2. Check if the same mobile number has already been added into the database with the same ticket. One mobile number can have multiple tickets, but each ticket should be different. One person cannot have multiple of the same tickets. If that happens, inform the user right there and don't save the ticket to the session. Cross check this in the sessoin as well. two tickets should not have the same name and the same mobile numeber.
			3. Also, the conflicting timing tickets should not be bought by the same phone number. For example, the ticket for Day2 session1 and Full Day2 ticket should not be booked for the same phone number.
		 */
		/* Adding ticket's name and other additional automatic information into the object END */

		/* Save the values sent in the form into the session as a ticket. ( add to CART) */

		/* Add the new ticket object to the session object */
		$timestamp = time();
		$temporary_tickets_object = new stdClass;
		$temporary_tickets_object = json_decode($session->tickets_json);
		$temporary_tickets_object->$timestamp = $attendee_ticket_info_object;
		$session->tickets_json = json_encode($temporary_tickets_object);
	}
	/* Add the new ticket object to the session object END */

	/* Save the values sent in the form into the session as a ticket. ( add to CART) END */
	
//	header("Location: ".$pages->get("name=cart")->httpUrl);
}
/* if the ticket booking form is submitted, save the information in the session END */


?>

<!DOCTYPE html>
<html>

<head>
	<title><?= $page->title ?></title>
</head>

<body>


	<!-- Form to add the ticket to the cart. -->
	<!-- TODO 
	1. Add design
	2. Add moe fields from the flow documentand differnet types of fields like dropdown and radio, etc. as needed
	3. Form validation especially mobile number. It is required that the phone number is perfect.
	4. The mobile number is to be put twice to confirm
	5. Front and backend both validation should happen.
	6. submit button should have a unique name as given already (add_ticket_submit) 
	7. Form target should be this page.
	
	-->
	<!--<a href="<?= $page->parent->parent->httpUrl ?>">back</a>-->
	<!--<form method="POST">-->
	<!--	attendee_name<input type="text" name="attendee_name" required>-->
	<!--	attendee_country_code<input type="text" name="attendee_country_code">-->
	<!--	attendee_phone_number<input type="text" name="attendee_phone_number" required>-->
	<!--	<button type="submit" name="add_ticket_submit">Submit</button>-->
	<!--</form>-->
	<!--<a href="<?= $page->parent->parent->httpUrl ?>cart">go to cart</a>-->
	<!-- Form to add the ticket to the cart END -->
	
<a href="<?= $page->parent->url ?>"><button type="button" class="btn btn-primary">Add More</button></a>	
<a href="<?= $pages->get("name=cart")->httpUrl ?>"><button type="button" class="btn btn-primary">Checkout</button></a>	

	
	<div class="">
	    <div class="row">
	        <div class="col-md-4">
	            
	        </div>
	         <div class="col-md-4">
	                <form id="main-container"  class="[ my-5 px-sm-5 ][ container rounded tab-content ][ needs-validation ]"  method="POST" enctype="multipart/form-data" novalidate>
		<!-- PERSONAL INFORMATION TAB -->
		
		            <?php
		                    echo $pages->get("name=cart")->httpUrl;
		            ?>
	                    	<div id="personal-tab" class="[ tab-pane fade show active ]" role="tabpanel" aria-labelledby="personal-tab">
                    			<div class="[ my-2 ][ text-center bg-primarya ]">
                    				<h3>Create Your Profile</h3>
                    			</div>
			
                        			<div class="[ ][ form-group ]">
                        				<label for="first_name">First name</label>
                        				<input id="legal_name" class="form-control" pattern="^[A-Za-z'\s\.\-]{1,}[\.]{0,}[A-Za-z'\s\.\-]{0,}$" type="text" name="legal_name" placeholder="First Name" required>
                        
                        				<div class="invalid-tooltip">
                        					Please provide a valid First name.
                        				</div>
                        			</div>
                                	<div class="[ ][ form-group ]">
                        				<label for="preferred_name">Last name</label>
                        				<input id="preferred_name" class="form-control" pattern="^[A-Za-z'\s\.\-]{1,}[\.]{0,}[A-Za-z'\s\.\-]{0,}$" type="text" name="preferred_name" placeholder="Last Name" required>
                        
                        				<div class="invalid-tooltip">
                        					Please provide a valid Last name.
                        				</div>
                        			</div>
			                        <div class="[ ][ form-group ]">
                        				<label for="pronoun">Pronoun</label>
                        				<select id="pronoun" class="custom-select" name="pronoun" required>
                        					<option value="" selected hidden>Pronoun</option>
                        					<option value="She/Her">She/Her</option>
                        					<option value="He/Him">He/Him</option>
                        					<option value="They/Them">They/Them</option>
                        					<option value="other">Other</option>
                        				</select>
                        
                        				<div class="invalid-tooltip">
                        					Please select a pronoun.
                        				</div>
                    			    </div>

                        			<div id="pronoun_custom_container" class="[ hidden ][ form-group ]">
                        				<label for="pronoun_custom">Please Enter Your Pronoun</label>
                        
                        				<input id="pronoun_custom" class="form-control" pattern="^[A-Za-z'\s\.\-\\\/]{1,}$" type="text" name="pronoun_custom" placeholder="Your Pronoun">
                        
                        				<div class="invalid-tooltip">
                        					Please state a valid pronoun.
                        				</div>
                        			</div>
			
			
			<div class="[ ][ form-group ]">
				<label for="phone_number">Phone number</label>

			        	<div class="row no-gutters">
        					<select id="phone_country_code" class="[ col-4 pl-2 ][ custom-select ]" name="phone_country_code">
        						<option value="+376">(AD) +376</option>
        						<option value="+971">(AE) +971</option>
        						<option value="+93">(AF) +93</option>
        						<option value="+1-268">(AG) +1-268</option>
        						<option value="+1-264">(AI) +1-264</option>
        						<option value="+355">(AL) +355</option>
        						<option value="+374">(AM) +374</option>
        						<option value="+599">(AN) +599</option>
        						<option value="+244">(AO) +244</option>
        						<option value="+672">(AQ) +672</option>
        						<option value="+54">(AR) +54</option>
        						<option value="+1-684">(AS) +1-684</option>
        						<option value="+43">(AT) +43</option>
        						<option value="+61">(AU) +61</option>
        						<option value="+297">(AW) +297</option>
        						<option value="+994">(AZ) +994</option>
        						<option value="+387">(BA) +387</option>
        						<option value="+1-246">(BB) +1-246</option>
        						<option value="+880">(BD) +880</option>
        						<option value="+32">(BE) +32</option>
        						<option value="+226">(BF) +226</option>
        						<option value="+359">(BG) +359</option>
        						<option value="+973">(BH) +973</option>
        						<option value="+257">(BI) +257</option>
        						<option value="+229">(BJ) +229</option>
        						<option value="+590">(BL) +590</option>
        						<option value="+1-441">(BM) +1-441</option>
        						<option value="+673">(BN) +673</option>
        						<option value="+591">(BO) +591</option>
        						<option value="+55">(BR) +55</option>
        						<option value="+1-242">(BS) +1-242</option>
        						<option value="+975">(BT) +975</option>
        						<option value="+267">(BW) +267</option>
        						<option value="+375">(BY) +375</option>
        						<option value="+501">(BZ) +501</option>
        						<option value="+1">(CA) +1</option>
        						<option value="+61">(CC) +61</option>
        						<option value="+243">(CD) +243</option>
        						<option value="+236">(CF) +236</option>
        						<option value="+242">(CG) +242</option>
        						<option value="+41">(CH) +41</option>
        						<option value="+225">(CI) +225</option>
        						<option value="+682">(CK) +682</option>
        						<option value="+56">(CL) +56</option>
        						<option value="+237">(CM) +237</option>
        						<option value="+86">(CN) +86</option>
        						<option value="+57">(CO) +57</option>
        						<option value="+506">(CR) +506</option>
        						<option value="+53">(CU) +53</option>
        						<option value="+238">(CV) +238</option>
        						<option value="+599">(CW) +599</option>
        						<option value="+61">(CX) +61</option>
        						<option value="+357">(CY) +357</option>
        						<option value="+420">(CZ) +420</option>
        						<option value="+49">(DE) +49</option>
        						<option value="+253">(DJ) +253</option>
        						<option value="+45">(DK) +45</option>
        						<option value="+1-767">(DM) +1-767</option>
        						<option value="+1-809">(DO) +1-809</option>
        						<option value="+213">(DZ) +213</option>
        						<option value="+593">(EC) +593</option>
        						<option value="+372">(EE) +372</option>
        						<option value="+20">(EG) +20</option>
        						<option value="+212">(EH) +212</option>
        						<option value="+291">(ER) +291</option>
        						<option value="+34">(ES) +34</option>
        						<option value="+251">(ET) +251</option>
        						<option value="+358">(FI) +358</option>
        						<option value="+679">(FJ) +679</option>
        						<option value="+500">(FK) +500</option>
        						<option value="+691">(FM) +691</option>
        						<option value="+298">(FO) +298</option>
        						<option value="+33">(FR) +33</option>
        						<option value="+241">(GA) +241</option>
        						<option value="+44">(GB) +44</option>
        						<option value="+1-473">(GD) +1-473</option>
        						<option value="+995">(GE) +995</option>
        						<option value="+44-1481">(GG) +44-1481</option>
        						<option value="+233">(GH) +233</option>
        						<option value="+350">(GI) +350</option>
        						<option value="+299">(GL) +299</option>
        						<option value="+220">(GM) +220</option>
        						<option value="+224">(GN) +224</option>
        						<option value="+240">(GQ) +240</option>
        						<option value="+30">(GR) +30</option>
        						<option value="+502">(GT) +502</option>
        						<option value="+1-671">(GU) +1-671</option>
        						<option value="+245">(GW) +245</option>
        						<option value="+592">(GY) +592</option>
        						<option value="+852">(HK) +852</option>
        						<option value="+504">(HN) +504</option>
        						<option value="+385">(HR) +385</option>
        						<option value="+509">(HT) +509</option>
        						<option value="+36">(HU) +36</option>
        						<option value="+62">(ID) +62</option>
        						<option value="+353">(IE) +353</option>
        						<option value="+972">(IL) +972</option>
        						<option value="+44-1624">(IM) +44-1624</option>
        						<option value="+91" selected>(IN) +91</option>
        						<option value="+246">(IO) +246</option>
        						<option value="+964">(IQ) +964</option>
        						<option value="+98">(IR) +98</option>
        						<option value="+354">(IS) +354</option>
        						<option value="+39">(IT) +39</option>
        						<option value="+44-1534">(JE) +44-1534</option>
        						<option value="+1-876">(JM) +1-876</option>
        						<option value="+962">(JO) +962</option>
        						<option value="+81">(JP) +81</option>
        						<option value="+254">(KE) +254</option>
        						<option value="+996">(KG) +996</option>
        						<option value="+855">(KH) +855</option>
        						<option value="+686">(KI) +686</option>
        						<option value="+269">(KM) +269</option>
        						<option value="+1-869">(KN) +1-869</option>
        						<option value="+850">(KP) +850</option>
        						<option value="+82">(KR) +82</option>
        						<option value="+965">(KW) +965</option>
        						<option value="+1-345">(KY) +1-345</option>
        						<option value="+7">(KZ) +7</option>
        						<option value="+856">(LA) +856</option>
        						<option value="+961">(LB) +961</option>
        						<option value="+1-758">(LC) +1-758</option>
        						<option value="+423">(LI) +423</option>
        						<option value="+94">(LK) +94</option>
        						<option value="+231">(LR) +231</option>
        						<option value="+266">(LS) +266</option>
        						<option value="+370">(LT) +370</option>
        						<option value="+352">(LU) +352</option>
        						<option value="+371">(LV) +371</option>
        						<option value="+218">(LY) +218</option>
        						<option value="+212">(MA) +212</option>
        						<option value="+377">(MC) +377</option>
        						<option value="+373">(MD) +373</option>
        						<option value="+382">(ME) +382</option>
        						<option value="+590">(MF) +590</option>
        						<option value="+261">(MG) +261</option>
        						<option value="+692">(MH) +692</option>
        						<option value="+389">(MK) +389</option>
        						<option value="+223">(ML) +223</option>
        						<option value="+95">(MM) +95</option>
        						<option value="+976">(MN) +976</option>
        						<option value="+853">(MO) +853</option>
        						<option value="+1-670">(MP) +1-670</option>
        						<option value="+222">(MR) +222</option>
        						<option value="+1-664">(MS) +1-664</option>
        						<option value="+356">(MT) +356</option>
        						<option value="+230">(MU) +230</option>
        						<option value="+960">(MV) +960</option>
        						<option value="+265">(MW) +265</option>
        						<option value="+52">(MX) +52</option>
        						<option value="+60">(MY) +60</option>
        						<option value="+258">(MZ) +258</option>
        						<option value="+264">(NA) +264</option>
        						<option value="+687">(NC) +687</option>
        						<option value="+227">(NE) +227</option>
        						<option value="+234">(NG) +234</option>
        						<option value="+505">(NI) +505</option>
        						<option value="+31">(NL) +31</option>
        						<option value="+47">(NO) +47</option>
        						<option value="+977">(NP) +977</option>
        						<option value="+674">(NR) +674</option>
        						<option value="+683">(NU) +683</option>
        						<option value="+64">(NZ) +64</option>
        						<option value="+968">(OM) +968</option>
        						<option value="+507">(PA) +507</option>
        						<option value="+51">(PE) +51</option>
        						<option value="+689">(PF) +689</option>
        						<option value="+675">(PG) +675</option>
        						<option value="+63">(PH) +63</option>
        						<option value="+92">(PK) +92</option>
        						<option value="+48">(PL) +48</option>
        						<option value="+508">(PM) +508</option>
        						<option value="+64">(PN) +64</option>
        						<option value="+1-787">(PR) +1-787</option>
        						<option value="+970">(PS) +970</option>
        						<option value="+351">(PT) +351</option>
        						<option value="+680">(PW) +680</option>
        						<option value="+595">(PY) +595</option>
        						<option value="+974">(QA) +974</option>
        						<option value="+262">(RE) +262</option>
        						<option value="+40">(RO) +40</option>
        						<option value="+381">(RS) +381</option>
        						<option value="+7">(RU) +7</option>
        						<option value="+250">(RW) +250</option>
        						<option value="+966">(SA) +966</option>
        						<option value="+677">(SB) +677</option>
        						<option value="+248">(SC) +248</option>
        						<option value="+249">(SD) +249</option>
        						<option value="+46">(SE) +46</option>
        						<option value="+65">(SG) +65</option>
        						<option value="+290">(SH) +290</option>
        						<option value="+386">(SI) +386</option>
        						<option value="+47">(SJ) +47</option>
        						<option value="+421">(SK) +421</option>
        						<option value="+232">(SL) +232</option>
        						<option value="+378">(SM) +378</option>
        						<option value="+221">(SN) +221</option>
        						<option value="+252">(SO) +252</option>
        						<option value="+597">(SR) +597</option>
        						<option value="+211">(SS) +211</option>
        						<option value="+239">(ST) +239</option>
        						<option value="+503">(SV) +503</option>
        						<option value="+1-721">(SX) +1-721</option>
        						<option value="+963">(SY) +963</option>
        						<option value="+268">(SZ) +268</option>
        						<option value="+1-649">(TC) +1-649</option>
        						<option value="+235">(TD) +235</option>
        						<option value="+228">(TG) +228</option>
        						<option value="+66">(TH) +66</option>
        						<option value="+992">(TJ) +992</option>
        						<option value="+690">(TK) +690</option>
        						<option value="+670">(TL) +670</option>
        						<option value="+993">(TM) +993</option>
        						<option value="+216">(TN) +216</option>
        						<option value="+676">(TO) +676</option>
        						<option value="+90">(TR) +90</option>
        						<option value="+1-868">(TT) +1-868</option>
        						<option value="+688">(TV) +688</option>
        						<option value="+886">(TW) +886</option>
        						<option value="+255">(TZ) +255</option>
        						<option value="+380">(UA) +380</option>
        						<option value="+256">(UG) +256</option>
        						<option value="+1">(US) +1</option>
        						<option value="+598">(UY) +598</option>
        						<option value="+998">(UZ) +998</option>
        						<option value="+379">(VA) +379</option>
        						<option value="+1-784">(VC) +1-784</option>
        						<option value="+58">(VE) +58</option>
        						<option value="+1-284">(VG) +1-284</option>
        						<option value="+1-340">(VI) +1-340</option>
        						<option value="+84">(VN) +84</option>
        						<option value="+678">(VU) +678</option>
        						<option value="+681">(WF) +681</option>
        						<option value="+685">(WS) +685</option>
        						<option value="+383">(XK) +383</option>
        						<option value="+967">(YE) +967</option>
        						<option value="+262">(YT) +262</option>
        						<option value="+27">(ZA) +27</option>
        						<option value="+260">(ZM) +260</option>
        						<option value="+263">(ZW) +263</option>
        					</select>

					<input id="phone_number" class="[ offset-1 col-7 pl-2 ][ form-control ]" pattern="[0-9]{10}" type="text" name="phone_number" placeholder="Example: 9876543210" maxlength="10" required>

					<div class="invalid-tooltip">
						Please provide a valid phone number.
					</div>
				</div>
			</div>
			
			<div class="[ ][ form-group ]">
				<label for="phone_number">Confirm Phone number</label>

				<div class="row no-gutters">
					<select id="WhatsApp_country_code" class="[ col-4 pl-2 ][ custom-select ]" name="WhatsApp_country_code">
						<option value="+376">(AD) +376</option>
						<option value="+971">(AE) +971</option>
						<option value="+93">(AF) +93</option>
						<option value="+1-268">(AG) +1-268</option>
						<option value="+1-264">(AI) +1-264</option>
						<option value="+355">(AL) +355</option>
						<option value="+374">(AM) +374</option>
						<option value="+599">(AN) +599</option>
						<option value="+244">(AO) +244</option>
						<option value="+672">(AQ) +672</option>
						<option value="+54">(AR) +54</option>
						<option value="+1-684">(AS) +1-684</option>
						<option value="+43">(AT) +43</option>
						<option value="+61">(AU) +61</option>
						<option value="+297">(AW) +297</option>
						<option value="+994">(AZ) +994</option>
						<option value="+387">(BA) +387</option>
						<option value="+1-246">(BB) +1-246</option>
						<option value="+880">(BD) +880</option>
						<option value="+32">(BE) +32</option>
						<option value="+226">(BF) +226</option>
						<option value="+359">(BG) +359</option>
						<option value="+973">(BH) +973</option>
						<option value="+257">(BI) +257</option>
						<option value="+229">(BJ) +229</option>
						<option value="+590">(BL) +590</option>
						<option value="+1-441">(BM) +1-441</option>
						<option value="+673">(BN) +673</option>
						<option value="+591">(BO) +591</option>
						<option value="+55">(BR) +55</option>
						<option value="+1-242">(BS) +1-242</option>
						<option value="+975">(BT) +975</option>
						<option value="+267">(BW) +267</option>
						<option value="+375">(BY) +375</option>
						<option value="+501">(BZ) +501</option>
						<option value="+1">(CA) +1</option>
						<option value="+61">(CC) +61</option>
						<option value="+243">(CD) +243</option>
						<option value="+236">(CF) +236</option>
						<option value="+242">(CG) +242</option>
						<option value="+41">(CH) +41</option>
						<option value="+225">(CI) +225</option>
						<option value="+682">(CK) +682</option>
						<option value="+56">(CL) +56</option>
						<option value="+237">(CM) +237</option>
						<option value="+86">(CN) +86</option>
						<option value="+57">(CO) +57</option>
						<option value="+506">(CR) +506</option>
						<option value="+53">(CU) +53</option>
						<option value="+238">(CV) +238</option>
						<option value="+599">(CW) +599</option>
						<option value="+61">(CX) +61</option>
						<option value="+357">(CY) +357</option>
						<option value="+420">(CZ) +420</option>
						<option value="+49">(DE) +49</option>
						<option value="+253">(DJ) +253</option>
						<option value="+45">(DK) +45</option>
						<option value="+1-767">(DM) +1-767</option>
						<option value="+1-809">(DO) +1-809</option>
						<option value="+213">(DZ) +213</option>
						<option value="+593">(EC) +593</option>
						<option value="+372">(EE) +372</option>
						<option value="+20">(EG) +20</option>
						<option value="+212">(EH) +212</option>
						<option value="+291">(ER) +291</option>
						<option value="+34">(ES) +34</option>
						<option value="+251">(ET) +251</option>
						<option value="+358">(FI) +358</option>
						<option value="+679">(FJ) +679</option>
						<option value="+500">(FK) +500</option>
						<option value="+691">(FM) +691</option>
						<option value="+298">(FO) +298</option>
						<option value="+33">(FR) +33</option>
						<option value="+241">(GA) +241</option>
						<option value="+44">(GB) +44</option>
						<option value="+1-473">(GD) +1-473</option>
						<option value="+995">(GE) +995</option>
						<option value="+44-1481">(GG) +44-1481</option>
						<option value="+233">(GH) +233</option>
						<option value="+350">(GI) +350</option>
						<option value="+299">(GL) +299</option>
						<option value="+220">(GM) +220</option>
						<option value="+224">(GN) +224</option>
						<option value="+240">(GQ) +240</option>
						<option value="+30">(GR) +30</option>
						<option value="+502">(GT) +502</option>
						<option value="+1-671">(GU) +1-671</option>
						<option value="+245">(GW) +245</option>
						<option value="+592">(GY) +592</option>
						<option value="+852">(HK) +852</option>
						<option value="+504">(HN) +504</option>
						<option value="+385">(HR) +385</option>
						<option value="+509">(HT) +509</option>
						<option value="+36">(HU) +36</option>
						<option value="+62">(ID) +62</option>
						<option value="+353">(IE) +353</option>
						<option value="+972">(IL) +972</option>
						<option value="+44-1624">(IM) +44-1624</option>
						<option value="+91" selected>(IN) +91</option>
						<option value="+246">(IO) +246</option>
						<option value="+964">(IQ) +964</option>
						<option value="+98">(IR) +98</option>
						<option value="+354">(IS) +354</option>
						<option value="+39">(IT) +39</option>
						<option value="+44-1534">(JE) +44-1534</option>
						<option value="+1-876">(JM) +1-876</option>
						<option value="+962">(JO) +962</option>
						<option value="+81">(JP) +81</option>
						<option value="+254">(KE) +254</option>
						<option value="+996">(KG) +996</option>
						<option value="+855">(KH) +855</option>
						<option value="+686">(KI) +686</option>
						<option value="+269">(KM) +269</option>
						<option value="+1-869">(KN) +1-869</option>
						<option value="+850">(KP) +850</option>
						<option value="+82">(KR) +82</option>
						<option value="+965">(KW) +965</option>
						<option value="+1-345">(KY) +1-345</option>
						<option value="+7">(KZ) +7</option>
						<option value="+856">(LA) +856</option>
						<option value="+961">(LB) +961</option>
						<option value="+1-758">(LC) +1-758</option>
						<option value="+423">(LI) +423</option>
						<option value="+94">(LK) +94</option>
						<option value="+231">(LR) +231</option>
						<option value="+266">(LS) +266</option>
						<option value="+370">(LT) +370</option>
						<option value="+352">(LU) +352</option>
						<option value="+371">(LV) +371</option>
						<option value="+218">(LY) +218</option>
						<option value="+212">(MA) +212</option>
						<option value="+377">(MC) +377</option>
						<option value="+373">(MD) +373</option>
						<option value="+382">(ME) +382</option>
						<option value="+590">(MF) +590</option>
						<option value="+261">(MG) +261</option>
						<option value="+692">(MH) +692</option>
						<option value="+389">(MK) +389</option>
						<option value="+223">(ML) +223</option>
						<option value="+95">(MM) +95</option>
						<option value="+976">(MN) +976</option>
						<option value="+853">(MO) +853</option>
						<option value="+1-670">(MP) +1-670</option>
						<option value="+222">(MR) +222</option>
						<option value="+1-664">(MS) +1-664</option>
						<option value="+356">(MT) +356</option>
						<option value="+230">(MU) +230</option>
						<option value="+960">(MV) +960</option>
						<option value="+265">(MW) +265</option>
						<option value="+52">(MX) +52</option>
						<option value="+60">(MY) +60</option>
						<option value="+258">(MZ) +258</option>
						<option value="+264">(NA) +264</option>
						<option value="+687">(NC) +687</option>
						<option value="+227">(NE) +227</option>
						<option value="+234">(NG) +234</option>
						<option value="+505">(NI) +505</option>
						<option value="+31">(NL) +31</option>
						<option value="+47">(NO) +47</option>
						<option value="+977">(NP) +977</option>
						<option value="+674">(NR) +674</option>
						<option value="+683">(NU) +683</option>
						<option value="+64">(NZ) +64</option>
						<option value="+968">(OM) +968</option>
						<option value="+507">(PA) +507</option>
						<option value="+51">(PE) +51</option>
						<option value="+689">(PF) +689</option>
						<option value="+675">(PG) +675</option>
						<option value="+63">(PH) +63</option>
						<option value="+92">(PK) +92</option>
						<option value="+48">(PL) +48</option>
						<option value="+508">(PM) +508</option>
						<option value="+64">(PN) +64</option>
						<option value="+1-787">(PR) +1-787</option>
						<option value="+970">(PS) +970</option>
						<option value="+351">(PT) +351</option>
						<option value="+680">(PW) +680</option>
						<option value="+595">(PY) +595</option>
						<option value="+974">(QA) +974</option>
						<option value="+262">(RE) +262</option>
						<option value="+40">(RO) +40</option>
						<option value="+381">(RS) +381</option>
						<option value="+7">(RU) +7</option>
						<option value="+250">(RW) +250</option>
						<option value="+966">(SA) +966</option>
						<option value="+677">(SB) +677</option>
						<option value="+248">(SC) +248</option>
						<option value="+249">(SD) +249</option>
						<option value="+46">(SE) +46</option>
						<option value="+65">(SG) +65</option>
						<option value="+290">(SH) +290</option>
						<option value="+386">(SI) +386</option>
						<option value="+47">(SJ) +47</option>
						<option value="+421">(SK) +421</option>
						<option value="+232">(SL) +232</option>
						<option value="+378">(SM) +378</option>
						<option value="+221">(SN) +221</option>
						<option value="+252">(SO) +252</option>
						<option value="+597">(SR) +597</option>
						<option value="+211">(SS) +211</option>
						<option value="+239">(ST) +239</option>
						<option value="+503">(SV) +503</option>
						<option value="+1-721">(SX) +1-721</option>
						<option value="+963">(SY) +963</option>
						<option value="+268">(SZ) +268</option>
						<option value="+1-649">(TC) +1-649</option>
						<option value="+235">(TD) +235</option>
						<option value="+228">(TG) +228</option>
						<option value="+66">(TH) +66</option>
						<option value="+992">(TJ) +992</option>
						<option value="+690">(TK) +690</option>
						<option value="+670">(TL) +670</option>
						<option value="+993">(TM) +993</option>
						<option value="+216">(TN) +216</option>
						<option value="+676">(TO) +676</option>
						<option value="+90">(TR) +90</option>
						<option value="+1-868">(TT) +1-868</option>
						<option value="+688">(TV) +688</option>
						<option value="+886">(TW) +886</option>
						<option value="+255">(TZ) +255</option>
						<option value="+380">(UA) +380</option>
						<option value="+256">(UG) +256</option>
						<option value="+1">(US) +1</option>
						<option value="+598">(UY) +598</option>
						<option value="+998">(UZ) +998</option>
						<option value="+379">(VA) +379</option>
						<option value="+1-784">(VC) +1-784</option>
						<option value="+58">(VE) +58</option>
						<option value="+1-284">(VG) +1-284</option>
						<option value="+1-340">(VI) +1-340</option>
						<option value="+84">(VN) +84</option>
						<option value="+678">(VU) +678</option>
						<option value="+681">(WF) +681</option>
						<option value="+685">(WS) +685</option>
						<option value="+383">(XK) +383</option>
						<option value="+967">(YE) +967</option>
						<option value="+262">(YT) +262</option>
						<option value="+27">(ZA) +27</option>
						<option value="+260">(ZM) +260</option>
						<option value="+263">(ZW) +263</option>
					</select>

					<input id="WhatsApp_number" class="[ offset-1 col-7 pl-2 ][ form-control ]" pattern="[0-9]{10}" type="text" name="WhatsApp_number" placeholder="Example: 9876543210" maxlength="10" required>

					<div class="invalid-tooltip">
						Please provide  a valid Phone number.
					</div>
						<div  class="[ text-danger ]" style="height: 1.3rem" >
				<div id="no_match" hidden="true">
					phone numbers do not match.
				</div>
			</div>
					
				</div>
			</div>
            	<div class="[  ][ form-group ]">
				<label for="email">Email</label>
				<input id="email" class="form-control" type="email" pattern='^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$' name="email" placeholder="abc@xyz.com" value="<?=$session->oauth_gmail;?>" required>

				<div class="invalid-tooltip">
					Please provide a valid email address.
				</div>
			</div>
		
			
            	<div class="[ form-group ]">
				<label for="company_name">Company Name</label>
				<input id="company_name" class="form-control" pattern="^[A-Za-z'\s\.\-]{1,}[\.]{0,}[A-Za-z'\s\.\-]{0,}$" type="text" name="company_name" placeholder="Company Name" required>

				<div class="invalid-tooltip">
					Please provide a valid Comapny name.
				</div>
			</div>
			
		</div>
			<!-- Buttons Section -->
			<div class="[ d-flex flex-row justify-content-between mb-4 ]">
				<button value="submit" class="btn btn-primary" type="submit" name="add_ticket_submit" >
					Submit
				</button>
			</div>
			<!-- Buttons Section End -->
    	</div>
		
		<!--</div>-->
		<!-- ADDITIONAL INFORMATION TAB -->
	</form>
	         </div>
	          <div class="col-md-4">
	              
	          </div>
	    </div>
	    
	    
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			$(document).on("keyup","#WhatsApp_number",  function(){
				if($(this).val() == $("#phone_number").val()){
					$("#submit").prop("disabled", false);
					$("#no_match").prop("hidden", true);
				}
				else{
					$("#submit").prop("disabled", true);
					$("#no_match").prop("hidden", false);
				}
			})


			/*$(".btn-submit").on('click', function(e){
				e.preventDefault();
				e.stopPropagation();

				if ($(this).closest('form').find('input, select, textbox').filter(function(){return this.checkValidity() === false}).length>0){
					$(this).closest('form').addClass('was-validated');
				}
				else{
					$(this).closest('form').submit();
				}
			})*/
		});

	// 	$(document).ready(function(){
    // 		$(document).on("keyup","#email",  function(){
    // 			return (/^([\w-.]+@(?!gmail\.com)(?!yahoo\.com)(?!outlook\.com)([\w-]+.)+[\w-]{2,4})?$/);
    // 			 message: 'Please enter your work email address';
	// 	})
	// });

	
				
	</script>	
	
	
<?php
    require_once 'includes/ticketing-footer.php';
 
?>
	
</body>

</html>