<?php
/*
	File created 2021-03-07
	Primary code by Amrut Todkar

	This page will show all the tickets to the user.
	Page will contain:
	-A list of all the tickets available for the conference
	-Each ticket will have an image and details of that event
	-Each ticket will come with a “Book” button.
	-After clicking on the “Book” button, the user will be taken to the single ticket details page
	-The header will have the banner image of the RISE event, below that,  a “cart” button showing the items in the cart. This will increase as each item is added to the cart.
	-The Footer will be similar as the RISE2021 microsite, containing the contact email ID, copyright statement.
	-A social media floating ribbon will be placed on the rightmost edge.

*/

	require_once 'includes/ticketing-header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tickets</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
  <style>
    .card-ticket-design
    {
        padding-top:2rem;
        padding-bottom:2rem;
    }
      
  </style>
</head>
<body>
    <h2 class="text-center">Tickets</h2>
<section>
    <!--full day session passes-->
     <div class="container">
        <div class="row">
            <?php
                foreach($pages->get("name=events")->children("start=0,limit=3") as $single_event_fullday ) 
                {
                    
               
            ?>
            <div class="col-sm-4 card-ticket-design">
                <div class="card " >
                  <div class="card-body">
                    <h5 class="card-title"><?=$single_event_fullday->title?></h5>
                    <p class="card-text"> <?=$single_event_fullday->ticketing_event_description?></p>
                        <!--<div class="d-flex justify-content-center">-->
                          
                        <!--</div>-->
                     <i class="fa fa-inr" aria-hidden="true" style="font-size:18px;"></i>
                     <?=$single_event_fullday->ticketing_event_price?>
                     <br/>
                    <a href="<?= $page->get("name=events")->child("title=".$single_event_fullday->title)->httpUrl ?>" class="btn btn-primary">BUY NOW</a>
                  </div>
                </div>
            </div>
            <!--<div class="col-sm-4 card-ticket-design">-->
            <!--    <div class="card">-->
            <!--      <div class="card-body">-->
            <!--        <h5 class="card-title">Day 2 Session-I & Session-II</h5>-->
            <!--        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
                     <!--<i class="fa fa-inr" aria-hidden="true" style="font-size:28px;"><h2>20</h2></i>-->
            <!--         <p><span style="font-size:30px;">₹</span>-->
                     <!--<h2>20  <small><del style="color:red;">40</del></small></h2></p>-->
                    
                    
            <!--         <br/>-->
            <!--        <a href="#" class="btn btn-primary">BUY NOW</a>-->
            <!--      </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--<div class="col-sm-4 card-ticket-design">-->
                <!--<div class="card">-->
                <!--  <div class="card-body">-->
                <!--    <h5 class="card-title">Day 1 & Day 2 (Session-I & Session-II)</h5>-->
                <!--    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
                <!--     <span style="font-size: 40px;">₨</span>-->
                <!--     <br/>-->
                <!--    <a href="#" class="btn btn-primary">BUY NOW</a>-->
                <!--  </div>-->
                <!--</div>-->
                <?php
                }
                
                ?>
            </div>
           
        </div>
  </div>
    
    <!--session passses-->
  <div class="container">
        <div class="row">
            <?php
                foreach($pages->get("name=events")->children("start=3,limit=4") as $single_event_fullday ) 
                {
                    
               
            ?>
            
            <div class="col-sm-6 card-ticket-design">
                <div class="card " >
                  <div class="card-body">
                    <h5 class="card-title"><?=$single_event_fullday->title?></h5>
                    <p class="card-text"><?=$single_event_fullday->ticketing_event_description?></p>
                   <i class="fa fa-inr" aria-hidden="true" style="font-size:18px;"></i>
                     <?=$single_event_fullday->ticketing_event_price?>
                     <br/>
                    <a href="<?= $page->get("name=events")->child("title=".$single_event_fullday->title)->httpUrl ?>" class="btn btn-primary">BUY NOW</a>
                  </div>
                </div>
            </div>
            <?php
                }
            ?>
            <!--<div class="col-sm-6 card-ticket-design">-->
            <!--    <div class="card">-->
            <!--      <div class="card-body">-->
            <!--        <h5 class="card-title">Day 1 Session-II</h5>-->
            <!--        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
            <!--        <a href="<?= $page->url ?>events/day-1-session-2" class="btn btn-primary">BUY NOW</a>-->
            <!--      </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--<div class="col-sm-6 card-ticket-design">-->
            <!--    <div class="card">-->
            <!--      <div class="card-body">-->
            <!--        <h5 class="card-title">Day 2 Session-I</h5>-->
            <!--        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
            <!--        <a href="#" class="btn btn-primary">BUY NOW</a>-->
                    
            <!--            <span style="font-size: 40px;">₨</span>-->
            <!--            <h3><?=$page->ticketing_event_price?></h3>-->
            <!--              <h3><?=$page->ticketing_event_price?></h3>-->
                        
                   
            <!--      </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--<div class="col-sm-6 card-ticket-design">-->
            <!--    <div class="card">-->
            <!--      <div class="card-body">-->
            <!--        <h5 class="card-title">Day 1 Session-II</h5>-->
            <!--        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
            <!--        <a href="#" class="btn btn-primary">BUY NOW</a>-->
            <!--      </div>-->
            <!--    </div>-->
            <!--</div>-->
        </div>
  </div>
</section>
    
    
<!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>-->
<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>    -->
<?php

    require_once 'includes/ticketing-footer.php';
?>
</body>
</html>