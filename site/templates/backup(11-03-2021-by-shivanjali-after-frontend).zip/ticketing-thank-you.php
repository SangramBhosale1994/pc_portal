<?php
require_once 'includes/ticketing-header.php';
//for loop for each 

if ($session->tickets_json != "{}") {
    $purchase_page = new Page();
    $purchase_page->template = 'ticketing-purchase';
    $purchase_array = [];
    foreach (json_decode($session->tickets_json) as $single_ticket) {
        //code to add attendee page and attendee register events
        //attendee page
        $attendee_page = $pages->get("name=attendee")->child("ticketing_attendee_phone_number=" . $single_ticket->attendee_phone_number);
        if ($attendee_page->id == 0) {
            $attendee_page = new Page();
        }
        $attendee_page->template = 'ticketing-attendee';
        $attendee_page->parent = $pages->get("name=attendee");
        $attendee_page->title = $single_ticket->attendee_name;
        $attendee_page->ticketing_attendee_phone_number = $single_ticket->attendee_phone_number;
        $attendee_page->of(false);
        $attendee_page->save();


        // create event page as child page 
        $flag = true;
        if ($pages->get("name=attendee")->child("ticketing_attendee_phone_number=" . $single_ticket->attendee_phone_number)->Children() > 0) {
            foreach ($attendee_page->children() as $attendee_page_child) {
                if ($attendee_page->child("ticketing_event_id=" . $single_ticket->event_id)->id) {
                    $flag = false;
                    echo "Can't buy this " . $single_ticket->event_id . " ticket twise<br>";
                }
            }
        }
        // if ($flag) {
        $event = new Page();
        $event->template = 'ticketing-attendee-single-event';
        $event->parent = $attendee_page; // new parent above
        $event->title = $single_ticket->event_id;
        $event->ticketing_event_page_id = $pages->get("name=events")->child("ticketing_event_id=" . $single_ticket->event_id)->id;
        $event->save();
        array_push($purchase_array, $event->id);
        // }
    }
    $purchase_page->ticketing_ticket_page_id = implode(',', $purchase_array);
    $purchase_page->parent = $pages->get("name=purchase");
    $purchase_page->title = time();
    $purchase_page->save();
}
$session->remove('tickets_json');
//print_r($session->tickets_json);

?>
<html>

<body>
    <h1>Thanks</h1>
</body>

</html>